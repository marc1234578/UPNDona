/* UPNDona: sesión, datos locales y utilidades compartidas */
(function () {
    'use strict';

    const STORAGE = {
        session: 'upndona_session',
        users: 'upndona_users',
        donations: 'upndona_donations',
        applications: 'upndona_volunteer_applications'
    };

    const demoUsers = [
        { id: 'USR-001', nombre: 'María Torres', email: 'admin@upn.edu.pe', password: 'Admin123', rol: 'admin', codigo: 'ADM-2026', campus: 'Breña', telefono: '987 654 321', estado: 'Activo' },
        { id: 'USR-002', nombre: 'Diego Salazar', email: 'voluntario@upn.edu.pe', password: 'Voluntario123', rol: 'voluntario', codigo: 'N00261472', campus: 'Los Olivos', telefono: '956 120 438', estado: 'Activo', horas: 28 },
        { id: 'USR-003', nombre: 'Andrea Ruiz', email: 'estudiante@upn.edu.pe', password: 'Estudiante123', rol: 'estudiante', codigo: 'N00198643', campus: 'Comas', telefono: '944 302 187', estado: 'Activo' },
        { id: 'USR-004', nombre: 'Luis Ramos', email: 'luis.ramos@upn.edu.pe', password: '', rol: 'estudiante', codigo: 'N00220184', campus: 'Breña', telefono: '933 475 210', estado: 'Activo' },
        { id: 'USR-005', nombre: 'Camila Soto', email: 'camila.soto@upn.edu.pe', password: '', rol: 'voluntario', codigo: 'N00184329', campus: 'San Juan de Lurigancho', telefono: '977 220 410', estado: 'Activo', horas: 16 }
    ];

    const demoDonations = [
        { id: 'DON-1048', nombre: 'Laptop HP 14 pulgadas', categoria: 'Electrónicos', donante: 'Carlos Mendoza', campus: 'Breña', estado: 'Pendiente', fecha: '20 Sep 2026', imagen: '💻' },
        { id: 'DON-1047', nombre: 'Colección de libros de cálculo', categoria: 'Libros', donante: 'Fernanda Paz', campus: 'Los Olivos', estado: 'Aprobada', fecha: '19 Sep 2026', imagen: '📚' },
        { id: 'DON-1046', nombre: 'Casaca universitaria talla M', categoria: 'Ropa', donante: 'Raúl Peña', campus: 'Comas', estado: 'En entrega', fecha: '18 Sep 2026', imagen: '🧥' },
        { id: 'DON-1045', nombre: 'Calculadora científica Casio', categoria: 'Electrónicos', donante: 'Lucía Flores', campus: 'Breña', estado: 'Pendiente', fecha: '18 Sep 2026', imagen: '🧮' },
        { id: 'DON-1044', nombre: 'Kit de dibujo técnico', categoria: 'Otros', donante: 'José Vidal', campus: 'Los Olivos', estado: 'Entregada', fecha: '17 Sep 2026', imagen: '📐' }
    ];

    const demoApplications = [
        { id: 'VOL-032', nombre: 'Valeria Núñez', codigo: 'N00235418', campus: 'Comas', disponibilidad: 'Tardes', estado: 'Pendiente' },
        { id: 'VOL-031', nombre: 'Mateo León', codigo: 'N00241977', campus: 'Breña', disponibilidad: 'Sábados', estado: 'Pendiente' },
        { id: 'VOL-030', nombre: 'Ariana Vega', codigo: 'N00197548', campus: 'Los Olivos', disponibilidad: 'Mañanas', estado: 'Aprobada' }
    ];

    function seedDemoData() {
        if (!localStorage.getItem(STORAGE.users)) localStorage.setItem(STORAGE.users, JSON.stringify(demoUsers));
        if (!localStorage.getItem(STORAGE.donations)) localStorage.setItem(STORAGE.donations, JSON.stringify(demoDonations));
        if (!localStorage.getItem(STORAGE.applications)) localStorage.setItem(STORAGE.applications, JSON.stringify(demoApplications));
        if (!localStorage.getItem('donaciones')) {
            localStorage.setItem('donaciones', JSON.stringify(demoDonations.filter(d => d.estado !== 'Pendiente').map(d => ({
                nombre: d.nombre, categoria: d.categoria.toLowerCase(), descripcion: `Donación disponible en el campus ${d.campus}.`, imagen: d.imagen, estado: d.estado
            }))));
        }
    }
    function read(key, fallback = []) {
        try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (_) { return fallback; }
    }

    function getSession() {
        try { return JSON.parse(sessionStorage.getItem(STORAGE.session)); } catch (_) { return null; }
    }

    function setSession(user) {
        const safeUser = { id: user.id, nombre: user.nombre, email: user.email, rol: user.rol, codigo: user.codigo, campus: user.campus, telefono: user.telefono || '' };
        sessionStorage.setItem(STORAGE.session, JSON.stringify(safeUser));
        sessionStorage.setItem('usuarioLogueado', user.nombre);
        return safeUser;
    }

    function authenticate(email, password) {
        seedDemoData();
        const user = read(STORAGE.users).find(u => u.email.toLowerCase() === String(email).trim().toLowerCase() && u.password === password);
        return user ? setSession(user) : null;
    }

    function register(data) {
        seedDemoData();
        const users = read(STORAGE.users);
        if (users.some(u => u.email.toLowerCase() === data.email.toLowerCase())) throw new Error('Ya existe una cuenta con este correo.');
        const user = { id: `USR-${String(users.length + 1).padStart(3, '0')}`, rol: 'estudiante', estado: 'Activo', ...data };
        users.push(user);
        localStorage.setItem(STORAGE.users, JSON.stringify(users));
        sessionStorage.setItem('usuarioRegistrado', data.nombre);
        return user;
    }

    function logout() {
        sessionStorage.removeItem(STORAGE.session);
        sessionStorage.removeItem('usuarioLogueado');
        location.href = 'index.html';
    }

    function homeForRole(role) {
        if (role === 'admin') return 'admin.html';
        if (role === 'voluntario') return 'voluntario-panel.html';
        return 'index.html';
    }

    function requireRole(role) {
        const session = getSession();
        if (!session) { location.replace(`login.html?next=${encodeURIComponent(location.pathname.split('/').pop())}`); return null; }
        if (role && session.rol !== role) { location.replace(homeForRole(session.rol)); return null; }
        return session;
    }
    function escapeHtml(value) {
        const node = document.createElement('div');
        node.textContent = value == null ? '' : String(value);
        return node.innerHTML;
    }

    function showToast(message) {
        const toast = document.getElementById('toast');
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add('is-visible');
        clearTimeout(showToast.timer);
        showToast.timer = setTimeout(() => toast.classList.remove('is-visible'), 2600);
    }

    function enhancePublicNavigation() {
        const session = getSession();
        document.querySelectorAll('#btn-iniciar').forEach(el => { el.style.display = session ? 'none' : 'flex'; });
        document.querySelectorAll('#btn-cerrar').forEach(el => {
            el.style.display = session ? 'flex' : 'none';
            el.onclick = (event) => { event.preventDefault(); logout(); };
        });
        if (!session) return;
        const actions = document.querySelector('.navbar-acciones');
        if (actions && !document.getElementById('cuenta-link')) {
            const link = document.createElement('a');
            link.id = 'cuenta-link';
            link.className = 'nav-account-link';
            link.href = session.rol === 'admin' ? 'admin.html' : session.rol === 'voluntario' ? 'voluntario-panel.html' : 'perfil.html';
            link.textContent = session.rol === 'admin' ? 'Panel admin' : session.rol === 'voluntario' ? 'Mi panel' : 'Mi perfil';
            actions.insertBefore(link, actions.firstChild);
        }
    }

    seedDemoData();
    document.addEventListener('DOMContentLoaded', () => {
        enhancePublicNavigation();
        const requiredRole = document.body.dataset.requiredRole;
        if (requiredRole) requireRole(requiredRole);
    });

    window.UPNDona = {
        STORAGE,
        seedDemoData, read, getSession, setSession, authenticate, register, logout,
        homeForRole, requireRole, escapeHtml, showToast
    };
})();
