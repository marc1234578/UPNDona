document.addEventListener('DOMContentLoaded', () => {
    const app = window.UPNDona;
    const session = app.requireRole('voluntario');
    if (!session) return;
    const initials = session.nombre.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
    document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = session.nombre);
    document.querySelectorAll('[data-user-email]').forEach(el => el.textContent = session.email);
    document.querySelectorAll('[data-first-name]').forEach(el => el.textContent = session.nombre.split(' ')[0]);
    document.querySelectorAll('[data-initials]').forEach(el => el.textContent = initials);
    document.querySelectorAll('[data-logout]').forEach(el => el.addEventListener('click', app.logout));

    const names = { inicio: 'Mi jornada', tareas: 'Mis tareas', horario: 'Mi horario', equipo: 'Mi equipo' };
    function openSection(name) {
        document.querySelectorAll('[data-section]').forEach(btn => btn.classList.toggle('active', btn.dataset.section === name));
        document.querySelectorAll('[data-content]').forEach(el => el.classList.toggle('active', el.dataset.content === name));
        document.getElementById('page-title').textContent = names[name];
        history.replaceState(null, '', `#${name}`);
        scrollTo({ top: 0, behavior: 'smooth' });
    }
    document.querySelectorAll('[data-section]').forEach(btn => btn.addEventListener('click', () => openSection(btn.dataset.section)));
    document.querySelectorAll('[data-section-jump]').forEach(btn => btn.addEventListener('click', () => openSection(btn.dataset.sectionJump)));
    if (names[location.hash.slice(1)]) openSection(location.hash.slice(1));

    let tasks = JSON.parse(localStorage.getItem('upndona_tasks') || 'null') || [
        { id: 1, titulo: 'Clasificar donaciones recibidas', descripcion: 'Revisar el estado y separar 12 artículos por categoría.', lugar: 'Almacén · Los Olivos', fecha: 'Lun 21 · 2:00 pm', estado: 'Pendiente', tipo: 'Inventario' },
        { id: 2, titulo: 'Confirmar datos de beneficiarios', descripcion: 'Contactar a 5 estudiantes antes de la jornada de entrega.', lugar: 'Remoto', fecha: 'Mar 22 · 4:00 pm', estado: 'Pendiente', tipo: 'Seguimiento' },
        { id: 3, titulo: 'Apoyar jornada de entregas', descripcion: 'Registrar firmas y verificar la entrega de los artículos.', lugar: 'Bienestar Estudiantil', fecha: 'Mié 23 · 10:00 am', estado: 'Pendiente', tipo: 'Entrega' },
        { id: 4, titulo: 'Inventario semanal', descripcion: 'Actualizar existencias y ubicación de artículos disponibles.', lugar: 'Almacén · Los Olivos', fecha: 'Vie 18 · 3:00 pm', estado: 'Completada', tipo: 'Inventario' }
    ];
    function renderTasks() {
        const filter = document.getElementById('task-filter').value;
        const filtered = tasks.filter(task => filter === 'Todas' || task.estado === filter);
        document.getElementById('task-grid').innerHTML = filtered.length ? filtered.map(task => `<article class="task-card"><div class="task-card-top"><span class="status ${task.estado === 'Completada' ? 'status-aprobada' : 'status-pendiente'}">${task.estado}</span><small>${task.tipo}</small></div><h3>${app.escapeHtml(task.titulo)}</h3><p>${app.escapeHtml(task.descripcion)}</p><div class="task-meta"><span>⌖ ${app.escapeHtml(task.lugar)}</span><span>□ ${app.escapeHtml(task.fecha)}</span></div><button class="portal-btn ${task.estado === 'Pendiente' ? 'primary' : ''}" style="width:100%" data-task="${task.id}">${task.estado === 'Pendiente' ? 'Marcar como completada' : 'Reabrir tarea'}</button></article>`).join('') : '<p>No hay tareas en este estado.</p>';
        document.getElementById('completed-count').textContent = 13 + tasks.filter(task => task.estado === 'Completada').length;
    }
    document.getElementById('task-filter').addEventListener('change', renderTasks);
    document.addEventListener('click', event => {
        const taskButton = event.target.closest('[data-task]');
        if (taskButton) {
            const task = tasks.find(item => item.id === Number(taskButton.dataset.task));
            task.estado = task.estado === 'Pendiente' ? 'Completada' : 'Pendiente';
            localStorage.setItem('upndona_tasks', JSON.stringify(tasks)); renderTasks(); app.showToast(`Tarea marcada como ${task.estado.toLowerCase()}.`);
        }
        const day = event.target.closest('[data-day]');
        if (day) day.classList.toggle('on');
        const toastButton = event.target.closest('[data-toast]');
        if (toastButton) app.showToast(toastButton.dataset.toast);
    });
    document.getElementById('save-schedule').addEventListener('click', () => app.showToast('Disponibilidad guardada correctamente.'));
    renderTasks();
});
