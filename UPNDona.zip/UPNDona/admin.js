/* Interacciones del panel administrativo */
document.addEventListener('DOMContentLoaded', () => {
    const app = window.UPNDona;
    const session = app.requireRole('admin');
    if (!session) return;

    const initials = name => name.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase();
    document.querySelectorAll('[data-user-name]').forEach(el => el.textContent = session.nombre);
    document.querySelectorAll('[data-user-email]').forEach(el => el.textContent = session.email);
    document.querySelectorAll('[data-initials]').forEach(el => el.textContent = initials(session.nombre));
    document.querySelectorAll('[data-first-name]').forEach(el => el.textContent = session.nombre.split(' ')[0]);
    document.querySelectorAll('[data-logout]').forEach(el => el.addEventListener('click', app.logout));

    const titleMap = { resumen: 'Centro de control', donaciones: 'Gestión de donaciones', solicitudes: 'Solicitudes de apoyo', usuarios: 'Usuarios y permisos', voluntariado: 'Equipo de voluntariado', reportes: 'Reportes de impacto' };
    function openSection(name) {
        document.querySelectorAll('[data-section]').forEach(btn => btn.classList.toggle('active', btn.dataset.section === name));
        document.querySelectorAll('[data-content]').forEach(section => section.classList.toggle('active', section.dataset.content === name));
        document.getElementById('page-title').textContent = titleMap[name] || 'Administración';
        history.replaceState(null, '', `#${name}`);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    document.querySelectorAll('[data-section]').forEach(btn => btn.addEventListener('click', () => openSection(btn.dataset.section)));
    document.querySelectorAll('[data-section-jump]').forEach(btn => btn.addEventListener('click', () => openSection(btn.dataset.sectionJump)));
    const initialSection = location.hash.slice(1);
    if (titleMap[initialSection]) openSection(initialSection);

    const statusClass = status => `status-${status.toLowerCase().replace(/\s+/g, '-')}`;
    let donations = app.read(app.STORAGE.donations);
    let users = app.read(app.STORAGE.users);
    let applications = app.read(app.STORAGE.applications);

    function renderDonations() {
        const query = document.getElementById('donation-search').value.trim().toLowerCase();
        const filter = document.getElementById('donation-filter').value;
        const filtered = donations.filter(item => (filter === 'Todos' || item.estado === filter) && [item.id, item.nombre, item.donante].join(' ').toLowerCase().includes(query));
        document.getElementById('donations-table').innerHTML = filtered.length ? filtered.map(item => `
            <tr><td><div class="table-primary"><span class="table-icon">${app.escapeHtml(item.imagen)}</span><span><strong>${app.escapeHtml(item.nombre)}</strong><small>${app.escapeHtml(item.id)} · ${app.escapeHtml(item.categoria)}</small></span></div></td>
            <td>${app.escapeHtml(item.donante)}</td><td>${app.escapeHtml(item.campus)}</td><td>${app.escapeHtml(item.fecha)}</td><td><span class="status ${statusClass(item.estado)}">${app.escapeHtml(item.estado)}</span></td>
            <td><div class="action-row">${item.estado === 'Pendiente' ? `<button class="portal-btn small primary" data-donation-action="approve" data-id="${item.id}">Aprobar</button><button class="portal-btn small danger" data-donation-action="reject" data-id="${item.id}">Rechazar</button>` : `<button class="portal-btn small" data-donation-action="advance" data-id="${item.id}">Actualizar</button>`}</div></td></tr>`).join('') : '<tr><td class="empty-row" colspan="6">No se encontraron donaciones con esos filtros.</td></tr>';
    }

    function updateDonation(id, action) {
        const item = donations.find(row => row.id === id);
        if (!item) return;
        if (action === 'approve') item.estado = 'Aprobada';
        if (action === 'reject') item.estado = 'Rechazada';
        if (action === 'advance') {
            const flow = { Aprobada: 'En entrega', 'En entrega': 'Entregada', Entregada: 'Entregada', Rechazada: 'Pendiente' };
            item.estado = flow[item.estado] || 'Aprobada';
        }
        localStorage.setItem(app.STORAGE.donations, JSON.stringify(donations));
        const publicDonations = app.read('donaciones');
        const publicItem = publicDonations.find(row => row.nombre === item.nombre && row.donante === item.donante);
        if (publicItem) {
            publicItem.validacion = item.estado === 'Rechazada' ? 'Rechazada' : item.estado === 'Pendiente' ? 'Pendiente' : 'Aprobada';
            localStorage.setItem('donaciones', JSON.stringify(publicDonations));
        }
        renderDonations();
        app.showToast(`Donación ${id}: estado actualizado a ${item.estado}.`);
    }

    function renderUsers() {
        const query = document.getElementById('user-search').value.trim().toLowerCase();
        const filter = document.getElementById('user-filter').value;
        const filtered = users.filter(user => (filter === 'Todos' || user.rol === filter) && [user.nombre, user.email, user.codigo].join(' ').toLowerCase().includes(query));
        document.getElementById('users-table').innerHTML = filtered.length ? filtered.map(user => `
            <tr><td><div class="table-primary"><span class="table-icon">${initials(user.nombre)}</span><span><strong>${app.escapeHtml(user.nombre)}</strong><small>${app.escapeHtml(user.email)} · ${app.escapeHtml(user.codigo)}</small></span></div></td>
            <td style="text-transform:capitalize">${app.escapeHtml(user.rol)}</td><td>${app.escapeHtml(user.campus || 'Sin asignar')}</td><td><span class="status ${statusClass(user.estado || 'Activo')}">${app.escapeHtml(user.estado || 'Activo')}</span></td>
            <td><div class="action-row"><button class="portal-btn small" data-user-role="${user.id}">${user.rol === 'voluntario' ? 'Hacer estudiante' : 'Hacer voluntario'}</button><button class="portal-btn small danger" data-user-toggle="${user.id}">${user.estado === 'Suspendido' ? 'Activar' : 'Suspender'}</button></div></td></tr>`).join('') : '<tr><td class="empty-row" colspan="5">No se encontraron usuarios.</td></tr>';
    }

    function renderApplications() {
        document.getElementById('applications-table').innerHTML = applications.map(item => `
            <tr><td><div class="table-primary"><span class="table-icon">${initials(item.nombre)}</span><span><strong>${app.escapeHtml(item.nombre)}</strong><small>${app.escapeHtml(item.codigo)}</small></span></div></td><td>${app.escapeHtml(item.campus)}</td><td>${app.escapeHtml(item.disponibilidad)}</td><td><span class="status ${statusClass(item.estado)}">${app.escapeHtml(item.estado)}</span></td>
            <td><div class="action-row">${item.estado === 'Pendiente' ? `<button class="portal-btn small primary" data-app-action="approve" data-id="${item.id}">Aprobar</button><button class="portal-btn small danger" data-app-action="reject" data-id="${item.id}">Rechazar</button>` : '<button class="portal-btn small" data-toast="Perfil de voluntariado revisado">Ver perfil</button>'}</div></td></tr>`).join('');
        document.getElementById('stat-applications').textContent = applications.filter(item => item.estado === 'Pendiente').length;
    }

    document.getElementById('donation-search').addEventListener('input', renderDonations);
    document.getElementById('donation-filter').addEventListener('change', renderDonations);
    document.getElementById('user-search').addEventListener('input', renderUsers);
    document.getElementById('user-filter').addEventListener('change', renderUsers);

    document.addEventListener('click', event => {
        const donationAction = event.target.closest('[data-donation-action]');
        if (donationAction) updateDonation(donationAction.dataset.id, donationAction.dataset.donationAction);
        const roleButton = event.target.closest('[data-user-role]');
        if (roleButton) {
            const user = users.find(item => item.id === roleButton.dataset.userRole);
            if (user && user.rol !== 'admin') user.rol = user.rol === 'voluntario' ? 'estudiante' : 'voluntario';
            localStorage.setItem(app.STORAGE.users, JSON.stringify(users)); renderUsers(); app.showToast('Rol de usuario actualizado.');
        }
        const toggleButton = event.target.closest('[data-user-toggle]');
        if (toggleButton) {
            const user = users.find(item => item.id === toggleButton.dataset.userToggle);
            if (user && user.rol !== 'admin') user.estado = user.estado === 'Suspendido' ? 'Activo' : 'Suspendido';
            localStorage.setItem(app.STORAGE.users, JSON.stringify(users)); renderUsers(); app.showToast('Estado de acceso actualizado.');
        }
        const applicationAction = event.target.closest('[data-app-action]');
        if (applicationAction) {
            const item = applications.find(row => row.id === applicationAction.dataset.id);
            item.estado = applicationAction.dataset.appAction === 'approve' ? 'Aprobada' : 'Rechazada';
            localStorage.setItem(app.STORAGE.applications, JSON.stringify(applications)); renderApplications(); app.showToast(`Postulación ${item.estado.toLowerCase()}.`);
        }
        const toastButton = event.target.closest('[data-toast]');
        if (toastButton) app.showToast(toastButton.dataset.toast);
    });

    document.getElementById('add-user').addEventListener('click', () => app.showToast('En este prototipo, los estudiantes se agregan desde Registro.'));
    document.getElementById('stat-donations').textContent = (1243 + donations.length).toLocaleString('es-PE');
    renderDonations(); renderUsers(); renderApplications();
});
